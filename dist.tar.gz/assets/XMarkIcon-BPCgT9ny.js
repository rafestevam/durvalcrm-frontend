import{j as e,y as o,m as r}from"./vendor-DuKM7o6i.js";function s(t,n){return r(),e("svg",{xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24","stroke-width":"1.5",stroke:"currentColor","aria-hidden":"true","data-slot":"icon"},[o("path",{"stroke-linecap":"round","stroke-linejoin":"round",d:"M6 18 18 6M6 6l12 12"})])}export{s as r};
//# sourceMappingURL=XMarkIcon-BPCgT9ny.js.map
